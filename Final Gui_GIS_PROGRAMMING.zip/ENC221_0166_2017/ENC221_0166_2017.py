import sys
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QDialog, QApplication, QFileDialog
from PyQt5.uic import loadUi

class MainWindow(QDialog):
    def __init__(self):
        super(MainWindow,self).__init__()
        loadUi("gui.ui",self)
        self.browse.clicked.connect(self.browsecountry)
        self.browse_2.clicked.connect(self.browsePOI)
        self.browse3.clicked.connect(self.browsePOI_specific)
        #self.OK1.clicked.connect(self.ok)
        #self.selectSpecificButton.clicked.connect(self.ok)

    def browsecountry(self):
        fname=QFileDialog.getOpenFileName(self, 'Open file', 'D:\codefirst.io\PyQt5 tutorials\Browse Files', 'Shapefiles (*.shp, *.csv *.TIFF, XML)')
        self.filename.setText(fname[0])
    def browsePOI(self):
        fname=QFileDialog.getOpenFileName(self, 'Open file', 'D:\codefirst.io\PyQt5 tutorials\Browse Files', 'Shapefiles (*.shp, *.csv *.TIFF, XML)')
        self.filename.setText(fname[0])
    def browsePOI_specific(self):
        loadUi ('specificPOI_new.ui', self)
        #self.filename.setText(fname[0])
        self.label.setText("Successful")
    def ok (self):
       self.label.setText("You successfully loaded the shapefiles")
   # class DialogWithButtonsRight (QDialog):
    #     super(DialogWithButtonsRight,self).__init__()
    #     self.selectSpecificButton.clicked.connect(self.ok)
   # def ok (self):
    #   self.label.setText("You successfully loaded the shapefiles")
#class DialogWithButtonsRight (QDialog):
   # def __init__(self):
    #    super(DialogWithButtonsRight,self).__init__()
     #   self.selectSpecificButton.clicked.connect(self.ok)
    #def ok (self):
    #   self.label.setText("You successfully loaded the shapefiles")



app=QApplication(sys.argv)
mainwindow=MainWindow()
widget=QtWidgets.QStackedWidget()
widget.addWidget(mainwindow)
widget.setFixedWidth(400)
widget.setFixedHeight(300)
widget.show()
sys.exit(app.exec_())
